<?php

use Illuminate\Database\Seeder;

class PagesDescriptionTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('pages_description')->delete();
        
        
        
    }
}